# Instalador StackOS Genesis — interface modernizada

Pacote 2.3-nodualboot+modern1, derivado do arquivo 2.2-nodualboot informado pelo usuário. Original preservado. Nenhuma mudança na ISO nem no Git.

## Interface

Logotipo real da distro; paleta azul, ciano e roxo; cartões e controles redesenhados; etapas com progresso; janela redimensionável; rolagem e navegação fixa. Mapa muda de duas colunas para uma em janelas menores. Textos com sequências literais de quebra de linha corrigidos. Entrada no menu de aplicativos incluída.

## Código

Comandos essenciais agora interrompem a instalação se falharem. Falhas da thread aparecem em uma tela própria, com registro em /var/log/stackos-installer.log; não apresentam conclusão falsa. Fechamento bloqueado durante a instalação. Corrigido comando que podia criar o usuário fora do chroot. Pré-validação recusa disco montado/em uso, destino inválido e disco menor que 40 GiB para o esquema existente de sistema/recuperação/backups. Verifica mídia e ferramentas antes de apagar. Aceita mídia em casper ou live. XML da política corrigido; permissões do sudoers normalizadas. Dependências gráficas e de particionamento explicitadas.

## Funcionalidades preservadas

Todos os métodos anteriores continuam presentes. Os 22 arquivos auxiliares do backend, recuperação, restauração de fábrica, snapshots e primeiro uso permaneceram idênticos. A configuração principal de conta continua no primeiro uso, como no pacote original. Esta variante nodualboot já desativava dual boot; não foi reativado nem removido seu código. O modo manual continua abrindo GParted, conforme o original. Não foi implementado um novo fluxo de particionamento manual.

O backend original instala GRUB UEFI. Agora o programa avisa antes de apagar caso tenha sido iniciado em BIOS legado; suporte BIOS completo ainda não foi implementado. A assinatura do pacote não certifica uma instalação real bem-sucedida.

## Verificação realizada

15 fontes Python compiladas; scripts shell com sintaxe verificada; XML lido com sucesso. Testes isolados de recusa de disco em uso/pequeno/inválido, privilégios, falha de comandos e modo de prévia. Oito telas renderizadas em 940×720 e 640×480, com navegação acessível e mapa responsivo. Não foi executada uma instalação real em disco ou VM com este pacote.

Para prévia após instalar o pacote: `stackos-installer --preview`. A prévia usa disco demonstrativo, não altera teclado, não abre GParted, não instala e não reinicia. Não instale este pacote num sistema de trabalho apenas para ver a interface: ele também contém integrações de inicialização e recuperação do pacote original.

Esta é uma candidata para avaliação antes de incorporar ao instalador oficial da ISO.
