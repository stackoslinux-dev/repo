# StackOS USB Writer 0.3.0

Imagens ISO/IMG e comprimidas GZ/XZ/BZ2/ZIP, SHA-256, gravacao verificada e formatacao FAT32/exFAT/NTFS.

Selecione explicitamente um USB e confirme seu nome antes de gravar. A autenticacao usa Polkit. Discos criticos e somente leitura sao recusados.

Cancelar nao restaura dados anteriores. Algumas ISOs Windows exigem preparacao especializada; nao ha conversao automatica ou multiboot.

A comparacao pos-gravacao permanece habilitada por padrao.
